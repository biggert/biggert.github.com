﻿/// Written by Joseph Biggert (jbiggert@cwithb.com) - http://www.cwithb.com
/// Use at your own risk :)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Messaging;
using System.Runtime.InteropServices.Automation;
using System.IO;
using System.Windows.Interop;
using System.Xml.Serialization;

namespace PopoutApplication
{
    public partial class MainPage : UserControl
    {
        #region PROPERTIES
        LocalMessageSender _mainAppSender = null;
        LocalMessageReceiver _mainAppReceiver;
        LocalMessageSender _spawnSender = null;
        LocalMessageReceiver _spawnReceiver = null;
        private bool _spawnMode = false;
        private bool _spawnAttached = false;

        #endregion

        #region CONSTRUCTORS
        public MainPage()
        {
            InitializeComponent();
        }

        #endregion

        #region EVENTS
        /// <summary>
        /// Loaded event for app
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            // Check to see if a message received exists on this system.
            try
            {
                _mainAppSender = new LocalMessageSender("MainApp", LocalMessageSender.Global);
                _mainAppSender.SendCompleted += new EventHandler<SendCompletedEventArgs>(loadSender_SendCompleted);
                _mainAppSender.SendAsync("Anyone out there?");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            // Populate our listbox for a complex example
            List<Customer> customers = new List<Customer>();
            customers.Add(new Customer("John Doe", "ABC Company"));
            customers.Add(new Customer("Jane Doe", "XYZ Company"));
            customers.Add(new Customer("Albert Simmons", "Image"));
            MainListBox.ItemsSource = customers;
        }

        /// <summary>
        /// Handle the SendCompleted event of the loading message sender
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void loadSender_SendCompleted(object sender, SendCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // We know we're the only app in town because there were no messages received


                // Let's set up a MainApp receiver
                _mainAppReceiver = new LocalMessageReceiver("MainApp", ReceiverNameScope.Global, LocalMessageReceiver.AnyDomain);
                _mainAppReceiver.MessageReceived += new EventHandler<MessageReceivedEventArgs>(_mainAppReceiver_MessageReceived);
                _mainAppReceiver.Listen();

                _spawnMode = false;
            }
            else
            {

                // Set up the message receiver
                _spawnReceiver = new LocalMessageReceiver("Spawn", ReceiverNameScope.Global, LocalMessageReceiver.AnyDomain);
                _spawnReceiver.MessageReceived += new EventHandler<MessageReceivedEventArgs>(_spawnReceiver_MessageReceived);
                _spawnReceiver.Listen();

                // Hey! We're a viewer cause a mainapp already exists! cool
                _spawnSender = new LocalMessageSender("MainApp", LocalMessageSender.Global);
                _spawnSender.SendCompleted += new EventHandler<SendCompletedEventArgs>(_spawnSender_SendCompleted);
                _spawnSender.SendAsync("I'm here!");


                _spawnMode = true;

            }

            // Clear out our sender
            _mainAppSender = null;


            SetDisplayMode();
        }

        /// <summary>
        /// Handle the SendCompleted event of the spawn's message sender
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void _spawnSender_SendCompleted(object sender, SendCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                MessageText.Text = "No Main app connected!";
            }
            else
                MessageText.Text = "We sent a message to the main app that says this: \"Hello Main!\"";
        }

        /// <summary>
        /// Handle the SendCompleted event of the Main application's message sender
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void MainAppSender_SendCompleted(object sender, SendCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // A little harsh but if we get an error, assume the spawn is dead in the water
                _spawnAttached = false;
                MessageText.Text = "No spawn connected!";
            }
            else
                MessageText.Text = "We sent a message to the spawn that says this: \"Hello spawn!\"";
        }

        /// <summary>
        /// MessageReceived event for main app receiver
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void _mainAppReceiver_MessageReceived(object sender, MessageReceivedEventArgs e)
        {
            // Handle the initial search message
            if (e.Message == "I'm here!")
            {
                // There's a viewer talking to us? Great! Let's send to it
                _mainAppSender = new LocalMessageSender("Spawn", LocalMessageSender.Global);
                _mainAppSender.SendCompleted += new EventHandler<SendCompletedEventArgs>(MainAppSender_SendCompleted);

                // I gots me a viewer!
                _spawnAttached = true;

            }
            else
            {
                MessageText.Text = "I got a message! It says \"" + e.Message + "\"";
            }
        }

        /// <summary>
        /// MessageReceived event for spawn receiver
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void _spawnReceiver_MessageReceived(object sender, MessageReceivedEventArgs e)
        {
            // A poor man's way of excluding the listbox selection
            if (!e.Message.Contains("<"))
                MessageText.Text = "I got a message! It says \"" + e.Message + "\"";
            else
            {
                Customer customer = null;
                using (StringReader sr = new StringReader(e.Message))
                {

                    System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(Customer));
                    customer = (Customer)serializer.Deserialize(sr);
                    sr.Close();
                }

                MessageText.Text = "Customer Selected: Name-" + customer.Name + ", Company-" + customer.Company;
            }
        }

        /// <summary>
        /// Click event for button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SpawnInstance_Click(object sender, RoutedEventArgs e)
        {
            string appID = string.Empty;

            if (Application.Current.IsRunningOutOfBrowser
                && Application.Current.HasElevatedPermissions
                && AutomationFactory.IsAvailable)
            {
                dynamic cmd = AutomationFactory.CreateObject("WScript.Shell");

                string localPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                localPath = localPath.Substring(0, localPath.LastIndexOf("\\") + 1);
                if (localPath.IndexOf("Documents and Settings") > 0)
                    localPath += "Local Settings\\Application Data\\Microsoft\\Silverlight\\OutOfBrowser\\";
                else
                    localPath += "AppData\\LocalLow\\Microsoft\\Silverlight\\OutOfBrowser\\";

                cmd.Run("xcopy \"" + localPath + "\\index\" \"" + Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\index\"  /E /C /Q /H /Y /I", 2, true);
                while (!File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\index\\localhost")) ;
                using (StreamReader fr = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\index\\localhost", System.Text.Encoding.Unicode))
                {
                    while (fr.Peek() >= 0)
                    {
                        //byte[] bt = System.Text.Encoding.Convert(System.Text.Encoding.Unicode, System.Text.Encoding.UTF8, System.Text.Encoding.Unicode.GetBytes(fr.ReadLine()));
                        string[] nextLn = fr.ReadLine().Split(new string[] { " ", "\t" }, StringSplitOptions.RemoveEmptyEntries);

                        if (nextLn != null && nextLn.Length > 1)
                        {

                            if (Application.Current.Host.Source.OriginalString.Equals(nextLn[1]))
                                appID = nextLn[0];
                        }
                    }
                }


                // Clean up the folder
                try
                {
                    DirectoryInfo index = new DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\index\\");
                    index.Delete(true);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Unable to clean up folder: " + ex.Message);
                }

                if (Environment.OSVersion.Version.Major <= 5)
                    cmd.Run("\"C:\\Program Files\\Microsoft Silverlight\\sllauncher.exe\" " + appID + ".localhost", 1, false);
                else
                    cmd.Run("\"C:\\Program Files (x86)\\Microsoft Silverlight\\sllauncher.exe\" " + appID + ".localhost", 1, false);
            }
            else
                MessageBox.Show("Application must be installed and running in Out of Browser mode!");

        }

        /// <summary>
        /// Click event for button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SendMessage_Click(object sender, RoutedEventArgs e)
        {

            if (_spawnMode)
            {
                MessageText.Text = "Sending message to Main";
                _spawnSender.SendAsync("Hello Main!");
            }
            else
            {
                if (_spawnAttached)
                {
                    MessageText.Text = "Sending message to Spawn";
                    _mainAppSender.SendAsync("Hello Spawn!");
                }
                else
                    MessageBox.Show("You don't have a spawn attached!");
            }


        }

        /// <summary>
        /// Click event for button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Fullscreen_Click(object sender, RoutedEventArgs e)
        {
            if (App.Current.Host.Content.IsFullScreen)
            {
                App.Current.Host.Content.FullScreenOptions = FullScreenOptions.StaysFullScreenWhenUnfocused;
                App.Current.Host.Content.IsFullScreen = false;
            }
            else
                App.Current.Host.Content.IsFullScreen = true;

        }

        /// <summary>
        /// SelectionChanged event for listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (MainListBox.SelectedItem != null)
            {
                if (_spawnAttached)
                {
                    // Just showing an example where you could serialize a string to send
                    StringWriter outStream = new StringWriter();
                    XmlSerializer s = new XmlSerializer(typeof(Customer));
                    s.Serialize(outStream, MainListBox.SelectedItem as Customer);
                    _mainAppSender.SendAsync(outStream.ToString());
                }
            }
        }

        #endregion

        #region METHODS
        /// <summary>
        /// Set the current display mode depending on if we are the main app or the spawn
        /// </summary>
        private void SetDisplayMode()
        {
            if (_spawnMode)
            {
                LayoutRoot.Background = new SolidColorBrush(Colors.Yellow);
                SpawnInstance.IsEnabled = false;
                IdentityLabel.Text = "I am a Spawn!";
                MainListBox.Visibility = System.Windows.Visibility.Collapsed;
            }
            else
            {
                LayoutRoot.Background = new SolidColorBrush(Colors.Gray);
                SpawnInstance.IsEnabled = true;
                IdentityLabel.Text = "I am the Main Application!";
                MainListBox.Visibility = System.Windows.Visibility.Visible;
            }
        }

        #endregion

    }

    /// <summary>
    /// My little dummy demonstration class because structs aren't my style.
    /// </summary>
    public class Customer
    {
        public string Name { get; set; }

        public string Company { get; set; }

        public string ToString()
        {
            return Name;
        }

        public Customer()
        {

        }

        public Customer(string name, string company)
        {
            Name = name;
            Company = company;
        }
    }
}
