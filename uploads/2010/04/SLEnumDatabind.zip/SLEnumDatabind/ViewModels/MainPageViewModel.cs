﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SLEnumDatabind.Models;
using System.Collections.ObjectModel;
using System.Reflection;

namespace SLEnumDatabind.ViewModels
{
    public class MainPageViewModel : ViewModelBase
    {
        private ObservableCollection<ZoomOption> _zoomOptions;
        public ObservableCollection<ZoomOption> ZoomOptions
        {
            get
            {
                return _zoomOptions;
            }

            set
            {
                _zoomOptions = value;
                RaisePropertyChanged("ZoomOptions");


            }
        }
        
        private ZoomOption _selectedZoomOption = ZoomOption.OneHundred;
        public ZoomOption SelectedZoomOption
        {
            get
            {
                return _selectedZoomOption;
            }

            set
            {
                _selectedZoomOption = value;
                RaisePropertyChanged("SelectedZoomOption");


            }
        }

        public MainPageViewModel()
        {
            // Get the type
            Type enumType = typeof(ZoomOption);

            // Set up a new collection
            ZoomOptions = new ObservableCollection<ZoomOption>();

            // Retrieve the info for the type (it'd be nice to use Enum.GetNames here but alas, we're stuck with this)
            FieldInfo[] infos;
            infos = enumType.GetFields(BindingFlags.Public | BindingFlags.Static);

            // Add each proper enum value to the collection
            foreach (FieldInfo fi in infos)
            {
                ZoomOptions.Add((ZoomOption)Enum.Parse(enumType, fi.Name, true));
            }
        }
    }
}
