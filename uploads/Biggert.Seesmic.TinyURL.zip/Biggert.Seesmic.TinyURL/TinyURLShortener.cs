﻿using Seesmic.Sdp.Extensibility;
using System;
using System.ComponentModel.Composition;
using System.Net;
using System.Net.Browser;
using System.Windows;
using System.Windows.Browser;
using System.Windows.Markup;


namespace Biggert.Seesmic.TinyURL
{

    [Export(typeof(IShortUrlProvider))]
    public class TinyURLShortener : IShortUrlProvider
    {
        private const string TINYURL_SHORTENER = @"http://tinyurl.com/api-create.php?url={0}";

        public void ShortUrlAsync(string longURL, object userState, AsyncCompletedCallback<string> callback)
        {
            WebRequest.RegisterPrefix("http://", WebRequestCreator.ClientHttp);
            WebClient client = new WebClient();
            client.DownloadStringCompleted += delegate(object s, DownloadStringCompletedEventArgs args)
            {
                if (args.Error == null)
                {
                    callback(this, new AsyncCompletedEventArgs<string>(null, false, userState, args.Result));
                }
                else
                {
                    callback(this, new AsyncCompletedEventArgs<string>(args.Error, false, userState, longURL));
                }
            };
            client.DownloadStringAsync(new Uri(string.Format(TINYURL_SHORTENER, longURL)));
        }

        public DataTemplate Icon
        {
            get
            {
                return (DataTemplate)XamlReader.Load("<DataTemplate><Image Source=\"/Biggert.Seesmic.TinyURL;component/Assets/Images/TinyURL-Logo.png\" Width=\"16\" Height=\"16\" /></DataTemplate>");
            }
        }

        public string Id
        {
            get
            {
                return "4739ab03-2eea-4fcb-8ec0-0a8931e8e75b";
            }
        }

        public string Text
        {
            get
            {
                return "TinyURL";
            }
        }
    }
}

