﻿using Seesmic.Sdp.Extensibility;
using System;
using System.ComponentModel.Composition;
using System.Windows;


namespace Biggert.Seesmic.TinyURL
{

    [Export(typeof(IPlugin))]
    public class TinyURLPlugin : IPlugin
    {
        public static ILogService _log;
        public static IShellService _shell;
        public static IStorageService _storage;

        static TinyURLPlugin()
        {

        }

        public void CommitSettings()
        {
        }

        public void Initialize()
        {
        }

        public void RevertSettings()
        {
        }

        public Guid Id
        {
            get
            {
                return new Guid("4739ab03-2eea-4fcb-8ec0-0a8931e8e75b");
            }
        }

        public static ILogService LogService
        {
            get
            {
                return _log;
            }
        }

        [Import]
        public ILogService LogServiceImport
        {
            set
            {
                _log = value;
            }
        }

        public DataTemplate SettingsTemplate
        {
            get
            {
                return null;
            }
        }

        public static IShellService ShellService
        {
            get
            {
                return _shell;
            }
        }

        [Import]
        public IShellService ShellServiceImport
        {
            set
            {
                _shell = value;
            }
        }

        public static IStorageService StorageService
        {
            get
            {
                return _storage;
            }
        }

        [Import]
        public IStorageService StorageServiceImport
        {
            set
            {
                _storage = value;
            }
        }
    }
}

